package Models;

public class Student {

    private String FullName;
    private String FirstName;
    private String LastName;
    private String Gender;
    private String Email;
    private String ContractNo;
    private String StudentId;
    public String UserName;
    public String UserId;
    private String Faculty;
    private String TimePeriod;
    private String ProgramName;
    public String Course;

    public Student(String FullName, String FirstName, String LastName, String Gender,
            String Email, String ContractNo, String StudentId, String Faculty, String TimePeriod,
            String ProgramName) {

        this.FullName = FullName;
        this.UserName = FirstName;
        this.LastName = LastName;
        this.Gender = Gender;
        this.Email = Email;
        this.ContractNo = ContractNo;
        this.StudentId = StudentId;
        this.Faculty = Faculty;
        this.ProgramName = ProgramName;
        this.TimePeriod = TimePeriod;
    }

    public String createUserName() {

        UserName = FirstName.concat(LastName)+" ";
        return UserName;
    }
    
    public String makeUserId(){
          UserId=Faculty.concat(StudentId);
          return UserId;
    }

    public String selectCourse() {
        Course = TimePeriod.concat(ProgramName) + " ";
        return Course;
    }

}
